/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.sprojecktmk3;


/**
 *
 * @author tater
 */
public class SprojecktMk3 extends GameScreen2  {
    
//public static double x =Math.random()*5+1;
    public static void main(String[] args) {
        
        GameScreen2 game =  new GameScreen2();
        game.setSize(600,400);
       
        if(GameScreen2.begin==0){
GameScreen2.x=Math.random()*5+1;  
GameScreen2.begin++;
GameScreen2.x=(int)GameScreen2.x;
System.out.println(GameScreen2.x);
GameScreen2.x=(int)GameScreen2.x;

if((int)GameScreen2.x==1){
          GameScreen2.target="abstract";
         
        } else if((int)GameScreen2.x==2){
          GameScreen2.target="cemetery";
        } else if((int)GameScreen2.x==3){
           GameScreen2.target="nurse";
        } else if ((int)GameScreen2.x==4){
           GameScreen2.target="pharmacy";
        } else if ((int)GameScreen2.x==5){
            GameScreen2.target="climbing";
        }
 System.out.println(GameScreen2.target);
}
        
        game.setVisible(true);
        game.setDefaultCloseOperation(GameScreen2.EXIT_ON_CLOSE);
        
        
    }
}
//make sure you can physically go to project folder and place image into the project folder
//inside of jlable when choose icon go to porject folder and use the image there 
//this shoudl be able to acess that image 
//you have to make sure that it can find the image when you run it 